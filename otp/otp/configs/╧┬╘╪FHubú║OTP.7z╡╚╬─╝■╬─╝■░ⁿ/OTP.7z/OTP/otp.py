import nidcpower
import nidigital

